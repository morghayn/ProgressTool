<?php defined('_JEXEC') or die;

/**
 * (Admin) Class ProgressToolControllerProjects
 *
 * Controller for back-end projects functionality.
 *
 * @package ProgressTool
 * @subpackage admin
 * @since 0.5.0
 *
 * @author  Morgan Nolan <morgan.nolan@hotmail.com>
 * @link    https://github.com/morghayn
 */
class ProgressToolControllerProjects extends JControllerLegacy
{

}