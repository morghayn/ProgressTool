<?php defined('_JEXEC') or die;

/**
 * (Admin) Class ProgressToolControllerDashboard
 *
 * Controller for back-end dashboard functionality.
 *
 * @package ProgressTool
 * @subpackage admin
 * @since 0.5.0
 *
 * @author  Morgan Nolan <morgan.nolan@hotmail.com>
 * @link    https://github.com/morghayn
 */
class ProgressToolControllerDashboard extends JControllerLegacy
{

}