<?php defined('_JEXEC') or die;

/**
 * (Admin) Class ProgressToolControllerTasks
 *
 * Controller for back-end tasks functionality.
 *
 * @package ProgressTool
 * @subpackage admin
 * @since 0.5.0
 *
 * @author  Morgan Nolan <morgan.nolan@hotmail.com>
 * @link    https://github.com/morghayn
 */
class ProgressToolControllerTasks extends JControllerLegacy
{

}