<?php defined('_JEXEC') or die; ?>

<?php echo $this->loadTemplate('sidebar'); ?>

<!-- Main -->
<div id="main">
    <span class="openNavigation" onclick="openNav()">&#9776; navigation</span>
    <h1>Here we will have metrics and statistics!</h1>
</div>