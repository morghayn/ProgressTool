<?php defined('_JEXEC') or die; ?>

<div id="projectModal" class="projectModal">
    <!-- Modal content -->
    <div class="projectModalContent">
        <div class="projectModalHeader">
            <span class="closeProjectModal">&times;</span>
            <h2>Project Editor</h2>
        </div>
        <div id="projectEditorTable">

        </div>
    </div>
</div>