<?php defined('_JEXEC') or die;

/**
 * (Admin) Class ProgressToolModelMetrics
 *
 * Model for back-end metrics functionality.
 *
 * @package ProgressTool
 * @subpackage admin
 * @since 0.5.0
 *
 * @author  Morgan Nolan <morgan.nolan@hotmail.com>
 * @link    https://github.com/morghayn
 */
class ProgressToolModelMetrics extends JModelLegacy
{

}